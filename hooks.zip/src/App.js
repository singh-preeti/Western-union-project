import React from 'react';
import ClassCounterOne from './ClassCounterOne';
import CountApp from './CountApp';
import CounterExample from './CounterExample';
import HookCounter from './HookCounter';
import HookCounterOne from './HookCounterOne';
import ParentComponent from './Component/ParentComponent'

function App() {
    return(
        <div>
            <ParentComponent />
        </div>
    )
    }
    export default App;